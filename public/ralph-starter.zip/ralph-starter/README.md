# Ralph Mode - Autonomous AI Coding Loop

Ship features while you sleep. 🌙

## What is Ralph?

Ralph is a bash loop that runs Claude Code autonomously, implementing features from a PRD (Product Requirements Document) one by one until everything is done.

Named after Ralph Wiggum from The Simpsons, this pattern was created by Geoffrey Huntley and popularized by Ryan Carson.

## How It Works

```
┌─────────────────────────────────────────┐
│  You create a PRD with user stories     │
│              ↓                          │
│  Run ./ralph.sh                         │
│              ↓                          │
│  Claude picks a story (passes: false)   │
│              ↓                          │
│  Implements it following criteria       │
│              ↓                          │
│  Commits and marks passes: true         │
│              ↓                          │
│  Loops until all stories complete       │
│              ↓                          │
│  You wake up to shipped features! 🎉    │
└─────────────────────────────────────────┘
```

## Quick Start

### 1. Install Claude Code

```bash
npm install -g @anthropic-ai/claude-code
```

### 2. Set Up Ralph in Your Project

```bash
# Copy the ralph-starter folder to your project
cp -r ralph-starter/scripts your-project/
cp ralph-starter/AGENTS.md your-project/

# Make it executable
chmod +x your-project/scripts/ralph/ralph.sh
```

### 3. Create Your PRD

Edit `scripts/ralph/prd.json` with your user stories:

```json
{
  "project": "My App",
  "stories": [
    {
      "id": "US-1.1",
      "title": "Add login button",
      "acceptance_criteria": [
        "Button appears in header",
        "Clicking opens login modal",
        "Works on mobile"
      ],
      "passes": false
    }
  ]
}
```

### 4. Run Ralph

```bash
./scripts/ralph/ralph.sh 10
```

Ralph will run up to 10 iterations, implementing one story per iteration.

## Tips for Success

### Write Good Acceptance Criteria

Bad: "Login works"
Good: "User can enter email and password, click Submit, and see a success message"

### Keep Stories Small

Each story should be completable in one Claude Code session. If it's too big, break it down.

### Use AGENTS.md

Document patterns and gotchas in AGENTS.md so future iterations learn from past mistakes.

## Files

```
scripts/ralph/
├── ralph.sh      # The bash loop
├── prompt.md     # Instructions for Claude
├── prd.json      # Your user stories
└── progress.txt  # Learning log

AGENTS.md         # Long-term memory
```

## Credits

- **Geoffrey Huntley** - Created the Ralph pattern
- **Ryan Carson** - Popularized it with 700k+ views
- **ralphmode.com** - This starter kit

## License

MIT - Use it, modify it, ship features while you sleep!
